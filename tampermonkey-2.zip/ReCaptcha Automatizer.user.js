// ==UserScript==
// @name        ReCaptcha Automatizer
// @description Passes ReCaptcha automatically as long as no suspicious traffic was registered.
// @namespace   PK-22-tech Script
// @match       https://www.google.com/recaptcha/*
// @Author      PK-22-tech
// @grant       none
// @version     0.1.1
// ==/UserScript==

var min = 714;
var max = 1365;

function Sleep(milliseconds) {
     return new Promise(resolve => setTimeout(resolve, milliseconds));
}

async function Click() {
     var randVal = Math.floor(Math.random() * (max - min + 1)) + min;
     await Sleep(randVal); // Pausiert die Funktion für X Millisekunden
     document.getElementsByClassName('recaptcha-checkbox-checkmark')[0].click();
     console.log('click after ' + randVal + ' milliseconds');
}

var oldOnload = window.onload;

window.onload = function () {

    if (typeof oldOnload == 'function') {
       oldOnload();
    }

    Click();

}
