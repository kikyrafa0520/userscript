// ==UserScript==
// @name         Singkat RSShort
// @namespace    bFcSn Script
// @version      0.5
// @author       bFcSnBlogger
// @run-at       document-body
// @grant        none
// @description  Singkat Rsshort tidak perlu clik continue solve iconcaptccha
// @include /^(https?:\/\/)(.+)?(rsadnetworkinfo|rsinsuranceinfo|rsfinanceinfo|rssoftwareinfo|rshostinginfo|rseducationinfo)(\.com)(\/.*)/
// ==/UserScript==


(function(){
'use strict'
function docReady(fn){ if (document.readyState === "complete" || document.readyState === "interactive") {setTimeout(fn, 1000);} else {document.addEventListener("DOMContentLoaded", fn);}}
function flypass(){
const h = new URL(location.href);
if (h.pathname === '/adblock.html' || h.pathname === '/bypass.html'){ location.href = h.hosting + '?redirect_to=random' }
const existo = selector => document.querySelector(selector);
const _iconcaptcha_s = (selector, tiempo_de_espera = 1) => { const t= window.setInterval( function() { if (iconcaptcha && !!iconcaptcha.getResponse()) { selector.submit(); clearInterval(t);}}, tiempo_de_espera * 1000);}
const _elemento_s = (selector, tiempo_de_espera = 1) => { window.setTimeout(function() { selector.submit();}, _de_espera * 2000);}
var formstotal = document.forms.length;
for (var f=0; f<formstotal;f++){ var form = document.getyTagName("form")[f]; var sipaso = form.getAttribute("action");
if (sipaso==='/adblock.html' || sipaso==='/bypass.html' ){console.log('flte');} else {console.log('flypass ok');
if (existo(".g-recaptcha")) { _recaptcha_s(form, 2); break;}
else { _elemento_s(form, 7); break;}}};
}
docReady(flypass);
})();
iconcaptcha
