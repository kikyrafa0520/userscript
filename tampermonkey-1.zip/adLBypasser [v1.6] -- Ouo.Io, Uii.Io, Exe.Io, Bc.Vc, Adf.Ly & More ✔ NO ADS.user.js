// ==UserScript==
// @name               adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ NO ADS
// @name:ar            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ بدون إعلانات
// @name:bg            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ БЕЗ РЕКЛАМИ
// @name:cs            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ ŽÁDNÉ REKLAMY
// @name:da            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ INGEN ANNONCER
// @name:de            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ KEINE WERBUNG
// @name:el            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ ΧΩΡΙΣ ΔΙΑΦΗΜΙΣΕΙΣ
// @name:en            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ NO ADS
// @name:eo            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ NENIUJ REKLAMOJ
// @name:es            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ SIN ANUNCIOS
// @name:fi            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ EI MAINOKSIA
// @name:fr            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ PAS DE PUBS
// @name:fr-CA         adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ PAS DE PUBS
// @name:he            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ ללא פרסומות
// @name:hu            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ NINCSENEK HIRDETÉSEK
// @name:id            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ TANPA IKLAN
// @name:it            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ NESSUNA PUBBLICITÀ
// @name:ko            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ 광고 없음
// @name:ja            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ 広告なし
// @name:nb            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ NO ADS
// @name:nl            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ GEEN ADVERTENTIES
// @name:pl            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ BEZ REKLAM
// @name:pt-BR         adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ NO ADS
// @name:ro            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ FĂRĂ RECLAME
// @name:ru            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ БЕЗ РЕКЛАМЫ
// @name:sk            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ ŽIADNE REKLAMY
// @name:sr            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ НЕМА ОГЛАСА
// @name:sv            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ INGA ANNONSER
// @name:th            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ ไม่มีโฆษณา
// @name:tr            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ REKLAMSIZ
// @name:uk            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ НЕМАЄ РЕКЛАМИ
// @name:ug            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ NO ADS
// @name:vi            adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ KHÔNG QUẢNG CÁO
// @name:zh-CN         adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ 无广告
// @name:zh-TW         adLBypasser [v1.6] || Ouo.Io, Uii.Io, Exe.Io, Bc.Vc, Adf.Ly & More ✔ 無廣告
// @description        Quickly advertising link bypass script
// @description:ar     تخطي الاعلانات بسرعة
// @description:bg     Бързо рекламна връзка bypass скрипт
// @description:cs     Rychle reklamní propojení bypass skript
// @description:da     Hurtigt reklame link bypass script
// @description:de     Schnell werbung link bypass skript
// @description:el     Γρήγορη διαφημιστική σύνδεση δέσμης σύνδεσης
// @description:en     Quickly advertising link bypass script
// @description:eo     Rapide reklamanta ligilo bypass script
// @description:es     Enlace de publicidad rápidamente del script de bypass
// @description:fi     Nopeasti mainos linkki ohituskäsikirjoitus
// @description:fr     Script de bypass de liaison de publicité rapide
// @description:fr-CA  Script de bypass de liaison de publicité rapide
// @description:he     במהירות פרסום קישור לעקוף סקריפט
// @description:hu     Gyorsan hirdetési link bypass script
// @description:id     Script bypass tautan iklan cepat
// @description:it     Script di bypass di collegamento pubblicitario rapidamente
// @description:ja     迅速にリンクバイパススクリプトを広告する
// @description:ko     신속하게 광고 링크 바이 패스 스크립트
// @description:nb     Quickly advertising link bypass script
// @description:nl     Snel advertising link bypass script
// @description:pl     Szybkie skrypt obejścia linków reklamowych
// @description:pt-BR  Quickly advertising link bypass script
// @description:ro     Rapid publicitate link script bypass
// @description:ru     Быстрое рекламируйте скрипт обхода ссылки
// @description:sk     Rýchlo reklamný odkaz bypass script
// @description:sr     Брзо рекламне везе бипаит скрипта
// @description:sv     Snabbt reklam länk bypass script
// @description:th     Брзо рекламне везе бипаит скрипта
// @description:tr     Hızlı bir şekilde reklam linki geçme betiği
// @description:uk     Швидке рекламне посилання bypass
// @description:ug     Quickly advertising link bypass script
// @description:vi     Nhanh chóng quảng cáo liên kết bypass script
// @description:zh-CN  快速广告链接旁路脚本
// @description:zh-TW  快速廣告鏈接旁路腳本
// @author             fir4tozden
// @version            1.6
// @license            MIT
// @namespace          https://greasyfork.org/users/821317
// @match              *://*.ouo.io/*
// @match              *://*.ouo.press/*
// @match              *://*.uii.io/*
// @match              *://*.passgen.icu/*
// @match              *://*.wordcounter.icu/*
// @match              *://*.exe.io/*
// @match              *://*.exey.io/*
// @match              *://*.exey.app/*
// @match              *://*.bc.vc/*
// @match              *://*.bcvc.live/*
// @match              *://*.bcvc.xyz/*
// @match              *://*.ouo.today/*
// @match              *://*.doaipomer.com/*
// @match              *://*.adf.ly/*
// @match              *://*.hurirk.net/*
// @match              *://*.usfinf.net/*
// @match              *://*.xervoo.net/*
// @match              *://*.pro/*
// @match              *://*.met.bz/*
// @match              *://*.shrinkearn.com/*
// @match              *://*.tei.ai/*
// @match              *://*.makemoneywithurl.com/*
// @match              *://*.clk.sh/*
// @match              *://*.iir.ai/*
// @match              *://*.shrink.pe/*
// @match              *://*.aii.sh/*
// @match              *://*.shrtfly.com/*
// @match              *://*.stfly.me/*
// @match              *://*.nbyts.online/*
// @match              *://*.shrinkurl.org/*
// @match              *://*.shrinkme.io/*
// @match              *://*.shrinke.me/*
// @match              *://*.smoner.com/*
// @match              *://*.shortearn.eu/*
// @match              *://*.adfoc.us/*
// @match              *://*.fc.lc/*
// @match              *://*.fc-lc.com/*
// @match              *://*.tr.link/*
// @match              *://*.aylink.co/*
// @match              *://*.yindex.xyz/*
// @match              *://*.gitizle.vip/*
// @match              *://*.uzunversiyon.xyz/*
// @match              *://*.shtms.co/*
// @match              *://*.findi.pro/*
// @match              *://*.gitlink.pro/*
// @match              *://*.bildirim.eu/*
// @match              *://*.bildirim.in/*
// @match              *://*.ppcnt.net/*
// @match              *://*.pnd.tl/*
// @match              *://*.pnd.one/*
// @match              *://*.pnd.money/*
// @match              *://*.pnd.fyi/*
// @match              *://*.pndx.live/*
// @match              *://*.shr.cash/*
// @match              *://*.acn.vin/*
// @match              *://*.pubiza.com/*
// @match              *://*.lnk.parts/*
// @match              *://*.lnkparts.com/*
// @match              *://*.zunsoach.com/*
// @match              *://*.urlcik.com/*
// @match              *://*.recaptcha.net/recaptcha/*
// @match              *://*.google.com/recaptcha/*
// @icon               https://i.ibb.co/cbc2pJ5/unknown.png
// @require            https://code.jquery.com/jquery-3.6.0.min.js
// ==/UserScript==

$(function () {
    let e = new URLSearchParams(location.search)
        , t = {};
    if (location.hostname.endsWith("ouo.io") || location.hostname.endsWith("ouo.press"))
        if (location.pathname.startsWith("/go")) {
            let e = (location.hostname + Date.now())
                .split("-")
                .join("")
                .split("_")
                .join("")
                .split(".")
                .join("");
            t[e] = setInterval(() => {
                    $("#form-go")
                        .submit()
                }, 1e3), $("#form-go")
                .on("submit", n => {
                    clearInterval(t[e])
                })
        } else {
            let e = (location.hostname + Date.now())
                .split("-")
                .join("")
                .split("_")
                .join("")
                .split(".")
                .join("");
            t[e] = setInterval(() => {
                    $("#form-captcha")
                        .submit()
                }, 1e3), $("#form-captcha")
                .on("submit", n => {
                    clearInterval(t[e])
                })
        }
    else if (location.hostname.endsWith("passgen.icu") || location.hostname.endsWith("wordcounter.icu")) {
        if (document.querySelector("input[name='ad_form_data']")) setTimeout(() => {
            $.post("/links/go", {
                _method: document.querySelector("input[name='_method']")
                    .value
                , _csrfToken: document.querySelector("input[name='_csrfToken']")
                    .value
                , ad_form_data: document.querySelector("input[name='ad_form_data']")
                    .value
                , "_Token[fields]": document.querySelector("input[name='_Token[fields]']")
                    .value
                , "_Token[unlocked]": document.querySelector("input[name='_Token[unlocked]']")
                    .value
            }, e => {
                location.href = e.url
            })
        }, 5e3);
        else if (document.querySelector("#invisibleCaptchaShortlink")) {
            let e = (location.hostname + Date.now())
                .split("-")
                .join("")
                .split("_")
                .join("")
                .split(".")
                .join("");
            t[e] = setInterval(() => {
                    !1 === $("#invisibleCaptchaShortlink")
                        .is(":disabled") && $("#invisibleCaptchaShortlink")
                        .click()
                }, 1e3), $("#invisibleCaptchaShortlink")
                .on("click", n => {
                    clearInterval(t[e])
                })
        }
    } else if (location.hostname.endsWith("exey.io") || location.hostname.endsWith("exey.app"))
        if (document.querySelector("input[name='ad_form_data']")) setTimeout(() => {
            $.post("/links/go", {
                _method: document.querySelector("input[name='_method']")
                    .value
                , _csrfToken: document.querySelector("input[name='_csrfToken']")
                    .value
                , ad_form_data: document.querySelector("input[name='ad_form_data']")
                    .value
                , "_Token[fields]": document.querySelector("input[name='_Token[fields]']")
                    .value
                , "_Token[unlocked]": document.querySelector("input[name='_Token[unlocked]']")
                    .value
            }, e => {
                location.href = e.url
            })
        }, 1e4);
        else if (document.querySelector("#invisibleCaptchaShortlink")) {
        let e = (location.hostname + Date.now())
            .split("-")
            .join("")
            .split("_")
            .join("")
            .split(".")
            .join("");
        t[e] = setInterval(() => {
                !1 === $("#invisibleCaptchaShortlink")
                    .is(":disabled") && $("#invisibleCaptchaShortlink")
                    .click()
            }, 1e3), $("#invisibleCaptchaShortlink")
            .on("click", n => {
                clearInterval(t[e])
            })
    } else {
        let e = (location.hostname + Date.now())
            .split("-")
            .join("")
            .split("_")
            .join("")
            .split(".")
            .join("");
        t[e] = setInterval(() => {
                $("#before-captcha")
                    .submit()
            }, 1e3), $("#before-captcha")
            .on("submit", n => {
                clearInterval(t[e])
            })
    } else if (location.hostname.endsWith("bcvc.xyz") || location.hostname.endsWith("bcvc.live")) $.post("/ln.php?wds=" + xyz, {
        xdf: {
            afg: tZ
            , bfg: cW
            , cfg: cH
            , jki: tkn
            , dfg: sW
            , efg: sH
            , rt: $("#recaptchaToken")
                .val()
        }
        , ojk: "jfhg"
    }, e => {
        e = JSON.parse(e), location.href = e.message.url
    });
    else if (location.hostname.endsWith("ouo.today")) location.href = nextUrl;
    else if (location.hostname.endsWith("doaipomer.com")) window.close();
    else if (location.hostname.endsWith("hurirk.net") || location.hostname.endsWith("usfinf.net") || location.hostname.endsWith("xervoo.net"))
        if (location.pathname.startsWith("/ad/locked")) location.href = "/-" + e.get("h") + "/" + e.get("url");
        else {
            let e = (location.hostname + Date.now())
                .split("-")
                .join("")
                .split("_")
                .join("")
                .split(".")
                .join("");
            t[e] = setInterval(() => {
                $("#skip_bu2tton")
                    .attr("href") && (clearInterval(t[e]), location.href = decodeURIComponent($("#skip_bu2tton")
                        .attr("href")
                        .split("dest=")[1]))
            }, 1e3)
        }
    else if (location.hostname.endsWith(".pro") && location.pathname.startsWith("/pushredirect")) location.href = e.get("dest");
    else if (location.hostname.endsWith("met.bz")) $.post("/links/go", {
        _method: $("input[name='_method']")
            .val()
        , alias: $("input[name='alias']")
            .val()
        , _csrfToken: $("input[name='_csrfToken']")
            .val()
        , ci: $("input[name='ci']")
            .val()
        , cui: $("input[name='cui']")
            .val()
        , cii: $("input[name='cii']")
            .val()
        , ref: $("input[name='ref']")
            .val()
        , "_Token[fields]": $("input[name='_Token[fields]']")
            .val()
        , "_Token[unlocked]": $("input[name='_Token[unlocked]']")
            .val()
    }, e => {
        location.href = e.url
    });
    else if (location.hostname.endsWith("tei.ai")) {
        if (document.querySelector("input[name='ad_form_data']")) setTimeout(() => {
            $.post("/links/go", {
                _method: document.querySelector("input[name='_method']")
                    .value
                , ad_form_data: document.querySelector("input[name='ad_form_data']")
                    .value
            }, e => {
                location.href = e.url
            })
        }, 1e4);
        else if (document.querySelector("#continue")) {
            let e = (location.hostname + Date.now())
                .split("-")
                .join("")
                .split("_")
                .join("")
                .split(".")
                .join("");
            t[e] = setInterval(() => {
                    !1 === $("#continue")
                        .is(":disabled") && $("#continue")
                        .click()
                }, 1e3), $("#continue")
                .on("click", n => {
                    clearInterval(t[e])
                })
        }
    } else if (location.hostname.endsWith("makemoneywithurl.com")) $("#hidden form")
        .submit();
    else if (location.hostname.endsWith("iir.ai"))
        if (document.querySelector("input[name='ad_form_data']")) setTimeout(() => {
            $.post("/links/go", {
                _method: document.querySelector("input[name='_method']")
                    .value
                , _csrfToken: document.querySelector("input[name='_csrfToken']")
                    .value
                , ad_form_data: document.querySelector("input[name='ad_form_data']")
                    .value
                , "_Token[fields]": document.querySelector("input[name='_Token[fields]']")
                    .value
                , "_Token[unlocked]": document.querySelector("input[name='_Token[unlocked]']")
                    .value
            }, e => {
                location.href = e.url
            })
        }, 1e4);
        else if (document.querySelector("#invisibleCaptchaShortlink")) {
        let e = (location.hostname + Date.now())
            .split("-")
            .join("")
            .split("_")
            .join("")
            .split(".")
            .join("");
        t[e] = setInterval(() => {
                !1 === $("#invisibleCaptchaShortlink")
                    .is(":disabled") && document.querySelector("#invisibleCaptchaShortlink")
                    .click()
            }, 1e3), $("#invisibleCaptchaShortlink")
            .on("click", n => {
                clearInterval(t[e])
            })
    } else $("button[type='submit']")
        .click();
    else if (location.hostname.endsWith("aii.sh")) {
        if (document.querySelector("input[name='ad_form_data']")) setTimeout(() => {
            $.post("/links/go", {
                _method: document.querySelector("input[name='_method']")
                    .value
                , _csrfToken: document.querySelector("input[name='_csrfToken']")
                    .value
                , ad_form_data: document.querySelector("input[name='ad_form_data']")
                    .value
                , "_Token[fields]": document.querySelector("input[name='_Token[fields]']")
                    .value
                , "_Token[unlocked]": document.querySelector("input[name='_Token[unlocked]']")
                    .value
            }, e => {
                location.href = e.url
            })
        }, 5e3);
        else if (document.querySelector("#invisibleCaptchaShortlink")) {
            let e = (location.hostname + Date.now())
                .split("-")
                .join("")
                .split("_")
                .join("")
                .split(".")
                .join("");
            t[e] = setInterval(() => {
                    !1 === $("#invisibleCaptchaShortlink")
                        .is(":disabled") && $("#invisibleCaptchaShortlink")
                        .click()
                }, 1e3), $("#invisibleCaptchaShortlink")
                .on("click", n => {
                    clearInterval(t[e])
                })
        }
    } else if (location.hostname.endsWith("stfly.me")) document.querySelector("input[name='ad_form_data']") ? setTimeout(() => {
            $.post("/links/go", {
                _method: document.querySelector("input[name='_method']")
                    .value
                , _csrfToken: document.querySelector("input[name='_csrfToken']")
                    .value
                , ad_form_data: document.querySelector("input[name='ad_form_data']")
                    .value
                , "_Token[fields]": document.querySelector("input[name='_Token[fields]']")
                    .value
                , "_Token[unlocked]": document.querySelector("input[name='_Token[unlocked]']")
                    .value
            }, e => {
                location.href = e.url
            })
        }, 5e3) : $("#submit_data")
        .submit();
    else if (location.hostname.endsWith("nbyts.online"))
        if (document.querySelector("#invisibleCaptchaShortLink")) {
            let e = (location.hostname + Date.now())
                .split("-")
                .join("")
                .split("_")
                .join("")
                .split(".")
                .join("");
            t[e] = setInterval(() => {
                    !1 === $("#invisibleCaptchaShortlink")
                        .is(":disabled") && $("#invisibleCaptchaShortlink")
                        .click()
                }, 1e3), $("#invisibleCaptchaShortlink")
                .on("click", n => {
                    clearInterval(t[e])
                })
        } else location.href = $("#surl")
            .attr("href");
    else if (location.hostname.endsWith("shrinkurl.org")) {
        if (document.querySelector("input[name='ad_form_data']")) setTimeout(() => {
            $.post("/links/go", {
                _method: document.querySelector("input[name='_method']")
                    .value
                , _csrfToken: document.querySelector("input[name='_csrfToken']")
                    .value
                , ad_form_data: document.querySelector("input[name='ad_form_data']")
                    .value
                , "_Token[fields]": document.querySelector("input[name='_Token[fields]']")
                    .value
                , "_Token[unlocked]": document.querySelector("input[name='_Token[unlocked]']")
                    .value
            }, e => {
                location.href = e.url
            })
        }, 15e3);
        else if (document.querySelector("#invisibleCaptchaShortlink")) {
            let e = (location.hostname + Date.now())
                .split("-")
                .join("")
                .split("_")
                .join("")
                .split(".")
                .join("");
            t[e] = setInterval(() => {
                    !1 === $("#invisibleCaptchaShortlink")
                        .is(":disabled") && $("#invisibleCaptchaShortlink")
                        .click()
                }, 1e3), $("#invisibleCaptchaShortlink")
                .on("click", n => {
                    clearInterval(t[e])
                })
        }
    } else if (location.hostname.endsWith("shrinke.me")) {
        if (document.querySelector("input[name='ad_form_data']")) setTimeout(() => {
            $.post("/links/go", {
                _method: document.querySelector("input[name='_method']")
                    .value
                , _csrfToken: document.querySelector("input[name='_csrfToken']")
                    .value
                , ad_form_data: document.querySelector("input[name='ad_form_data']")
                    .value
                , "_Token[fields]": document.querySelector("input[name='_Token[fields]']")
                    .value
                , "_Token[unlocked]": document.querySelector("input[name='_Token[unlocked]']")
                    .value
            }, e => {
                location.href = e.url
            })
        }, 12e3);
        else if (document.querySelector("#invisibleCaptchaShortlink")) {
            let e = (location.hostname + Date.now())
                .split("-")
                .join("")
                .split("_")
                .join("")
                .split(".")
                .join("");
            t[e] = setInterval(() => {
                    !1 === $("#invisibleCaptchaShortlink")
                        .is(":disabled") && $("#invisibleCaptchaShortlink")
                        .click()
                }, 1e3), $("#invisibleCaptchaShortlink")
                .on("click", n => {
                    clearInterval(t[e])
                })
        }
    } else if (location.hostname.endsWith("smoner.com")) {
        if (document.querySelector("input[name='ad_form_data']")) setTimeout(() => {
            $.post("/links/go", {
                _method: document.querySelector("input[name='_method']")
                    .value
                , _csrfToken: document.querySelector("input[name='_csrfToken']")
                    .value
                , ad_form_data: document.querySelector("input[name='ad_form_data']")
                    .value
                , "_Token[fields]": document.querySelector("input[name='_Token[fields]']")
                    .value
                , "_Token[unlocked]": document.querySelector("input[name='_Token[unlocked]']")
                    .value
            }, e => {
                location.href = e.url
            })
        }, 15e3);
        else if (document.querySelector("#invisibleCaptchaShortlink")) {
            let e = (location.hostname + Date.now())
                .split("-")
                .join("")
                .split("_")
                .join("")
                .split(".")
                .join("");
            t[e] = setInterval(() => {
                    !1 === $("#invisibleCaptchaShortlink")
                        .is(":disabled") && $("#invisibleCaptchaShortlink")
                        .click()
                }, 1e3), $("#invisibleCaptchaShortlink")
                .on("click", n => {
                    clearInterval(t[e])
                })
        }
    } else if (location.hostname.endsWith("shortearn.eu")) {
        if (document.querySelector("input[name='ad_form_data']")) setTimeout(() => {
            $.post("/links/go", {
                _method: document.querySelector("input[name='_method']")
                    .value
                , _csrfToken: document.querySelector("input[name='_csrfToken']")
                    .value
                , ad_form_data: document.querySelector("input[name='ad_form_data']")
                    .value
                , "_Token[fields]": document.querySelector("input[name='_Token[fields]']")
                    .value
                , "_Token[unlocked]": document.querySelector("input[name='_Token[unlocked]']")
                    .value
            }, e => {
                location.href = e.url
            })
        }, 15e3);
        else if (document.querySelector("#invisibleCaptchaShortlink")) {
            let e = (location.hostname + Date.now())
                .split("-")
                .join("")
                .split("_")
                .join("")
                .split(".")
                .join("");
            t[e] = setInterval(() => {
                    !1 === $("#invisibleCaptchaShortlink")
                        .is(":disabled") && $("#invisibleCaptchaShortlink")
                        .click()
                }, 1e3), $("#invisibleCaptchaShortlink")
                .on("click", n => {
                    clearInterval(t[e])
                })
        }
    } else if (location.hostname.endsWith("adfoc.us")) click_url && (location.href = click_url);
    else if (location.hostname.endsWith("fc-lc.com")) document.querySelector("input[name='ad_form_data']") && $.post("/links/go", {
        ad_form_data: document.querySelector("input[name='ad_form_data']")
            .value
    }, e => {
        location.href = e.url
    });
    else if (location.hostname.endsWith("aylink.co") || location.hostname.endsWith("yindex.xyz") || location.hostname.endsWith("gitizle.vip") || location.hostname.endsWith("uzunversiyon.xyz") || location.hostname.endsWith("shtms.co") || location.hostname.endsWith("findi.pro") || location.hostname.endsWith("gitlink.pro")) "undefined" != typeof app && app.csrf && $.post("/get/tk", {
        _a: _a
        , _t: _t
        , _d: _d
    }, e => {
        $.post("/links/go2", {
            alias: location.pathname.substr(1, location.pathname.length - 1)
            , csrf: app.csrf
            , tkn: e.th
        }, e => {
            location.href = e.url
        })
    });
    else if (location.hostname.endsWith("bildirim.eu") || location.hostname.endsWith("bildirim.in")) $("#btnPermission")
        .click();
    else if (location.hostname.endsWith("ppcnt.net")) window.close();
    else if (location.hostname.endsWith("pnd.one") || location.hostname.endsWith("pnd.money") || location.hostname.endsWith("pnd.fyi") || location.hostname.endsWith("pndx.live") || location.hostname.endsWith("shr.cash") || location.hostname.endsWith("acn.vin"))
        if ($("input[name='ad_form_data']") && $("input[name='ad_form_data']")
            .val()) setTimeout(() => {
            $.post("/links/go", {
                _method: $("input[name='_method']")
                    .val()
                , _csrfToken: $("input[name='_csrfToken']")
                    .val()
                , ad_form_data: $("input[name='ad_form_data']")
                    .val()
                , "_Token[fields]": $("input[name='_Token[fields]']")
                    .val()
                , "_Token[unlocked]": $("input[name='_Token[unlocked]']")
                    .val()
            }, e => {
                location.href = e.url
            })
        }, 1e4);
        else {
            let e = (location.hostname + Date.now())
                .split("-")
                .join("")
                .split("_")
                .join("")
                .split(".")
                .join("");
            t[e] = setInterval(() => {
                    $("#link-view")
                        .submit()
                }, 1e3), $("#link-view")
                .on("submit", n => {
                    clearInterval(t[e])
                })
        }
    else if (location.hostname.endsWith("lnk.parts"))
        if (location.pathname.startsWith("/go")) $("head")
            .append('<script>$("#skip_form").submit();<\/script>');
        else {
            let e = (location.hostname + Date.now())
                .split("-")
                .join("")
                .split("_")
                .join("")
                .split(".")
                .join("");
            t[e] = setInterval(() => {
                    !1 === $("#csubmit")
                        .is(":disabled") && ($("#csubmit")
                            .click(), $("#csubmit")
                            .click())
                }, 1e3), $("#csubmit")
                .on("click", n => {
                    clearInterval(t[e])
                })
        }
    else if (location.hostname.endsWith("lnkparts.com") || location.hostname.endsWith("zunsoach.com")) window.close();
    else if (location.hostname.endsWith("urlcik.com")) {
        if (document.querySelector("input[name='ad_form_data']")) setTimeout(() => {
            $.post("/links/go", {
                _method: document.querySelector("input[name='_method']")
                    .value
                , _csrfToken: document.querySelector("input[name='_csrfToken']")
                    .value
                , ad_form_data: document.querySelector("input[name='ad_form_data']")
                    .value
                , "_Token[fields]": document.querySelector("input[name='_Token[fields]']")
                    .value
                , "_Token[unlocked]": document.querySelector("input[name='_Token[unlocked]']")
                    .value
            }, e => {
                location.href = e.url
            })
        }, 5e3);
        else if (document.querySelector("#invisibleCaptchaShortlink")) {
            let e = (location.hostname + Date.now())
                .split("-")
                .join("")
                .split("_")
                .join("")
                .split(".")
                .join("");
            t[e] = setInterval(() => {
                    !1 === $("#invisibleCaptchaShortlink")
                        .is(":disabled") && $("#invisibleCaptchaShortlink")
                        .click()
                }, 1e3), $("#invisibleCaptchaShortlink")
                .on("click", n => {
                    clearInterval(t[e])
                })
        }
    } else location.pathname.startsWith("/recaptcha") && setInterval(() => {
        $(".recaptcha-checkbox-checkmark")
            .click()
    }, 1e3)
});