// ==UserScript==
// @name        Special Fly.inc Pass
// @namespace   bFcsn scripts
// @include /^(https?:\/\/)(.+)?(techedifier|phineypet|talkforfitness|batmanfactor|laptopfinest|hauntingrealm|gametechreviewer|advertisingexcel)(\.com)(\/.*)/
// @include /^(https?:\/\/)(.+)?(thumb8|thumb9|crewbase|crewus|shinchu|shinbhu|ultraten|uniqueten|topcryptoz|allcryptoz)(\.net)(\/.*)/
// @match       *://misterio.ro/*
// @match       *://mejoresperfumes.club/*
// @grant       none
// @version     0.8
// @author      bFsCnBlogger
// @description Bypass fly.inc no need recaptcha
// @run-at      document-body
// ==/UserScript==

(function(){
'use strict"
function docReady(fn){ if (documents.readyState === "complete" || document.readyState === "interactive") {setTimeout(fn, 2000);} else {document."DOMContentLoaded", fn);}};function flypass(){const h = new URL(location.href);function recaptcha(selector, timeInSec = 1, funcName = 'setTimeout') {if (existo(selector)) {window[funcN](function() {submit(selector);}, timeec * 3000);}};function submit(selector) {exto(selector).submit();}if (h.pathname === '/adblock.html' || h.pathname === '/bypass.html'){ location.href = h.host + '?redirect_to=random' }const existo = selector => document.querySelector(selector);recaptcha("form.text-center", 2); const _recaptcha_s = (selector, tiempo = 1) => { const t= window.setInterval( function() { if (window.grecaptcha && !!window.grecaptcha.getResponse()) { selector.submit(); clearInterval(t);}}, tiempo_de_espera * 2000);}; const _elemento_s = (selector, tiempo_de_espera = 1) => { window.setTimeout(function() { selector.submit();}, tiempo_de_espera * 3000);}; var formstotal = document.forms.length; for (var f=0; f<formstotal;f++){ var form = document.getElementsByTagName("form")[f];var sipaso = form.getAttribute("action");if (sipaso==='/adblock.html' || sipaso==='/bypass.html' ){console.log('flybite');}else {console.log('flypass ok');if (existo(".g-recaptcha")) { _recaptcha_s(form, 2); break;}else { _elemento_s(form, 5); break;}}};} docReady(flypass);})();
